Link Github: https://github.com/montse4/Vampire-Killer
Team Member: Montserrat Medina
Usuario: montse4

Description:"Vampire Killer" is a classic action-adventure platformer developed by Konami for the MSX2 computer system in 1987. Set in a dark and foreboding Transylvanian castle, players control the vampire hunter Simon Belmont as he navigates  treacherous corridors, battles hordes of monsters, and confronts iconic bosses. Armed with the legendary whip known as the Vampire Killer, players must explore the castle's interconnected rooms, solve puzzles, and uncover hidden secrets to ultimately vanquish the lord of darkness and save the land from eternal night.

Controls: 
Left --> arrow left
Right --> arrow right
Up -->arrow up
Down -->arrow down

Play --> Space
Exit --> Esc

List of features implemented:
Background
Menu
Intro
Basic movement
Sprites
